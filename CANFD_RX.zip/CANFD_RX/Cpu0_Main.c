/********************************************************************************************************************
 * \file main.c
 * \note CAN FD Receiver Node (uses MCMCAN + MAC verification)
 ********************************************************************************************************************/

#include "Ifx_Types.h"
#include "IfxCpu.h"
#include "IfxScuWdt.h"
#include "MCMCAN.h"

/* Synchronization variable for multicore startup */
IFX_ALIGN(4) IfxCpu_syncEvent g_cpuSyncEvent = 0;

void core0_main(void)
{
    /* Enable CPU interrupts globally */
    IfxCpu_enableInterrupts();
    
    /* Disable watchdogs (for development/demo) */
    IfxScuWdt_disableCpuWatchdog(IfxScuWdt_getCpuWatchdogPassword());
    IfxScuWdt_disableSafetyWatchdog(IfxScuWdt_getSafetyWatchdogPassword());
    
    /* Synchronize with other CPU cores (if used) */
    IfxCpu_emitEvent(&g_cpuSyncEvent);
    IfxCpu_waitEvent(&g_cpuSyncEvent, 1);

    /* Initialize CAN FD receiver (MCMCAN Node 0, 64-byte payloads) */
    initMcmcan();

    /* Initialize LEDs for status indication */
    initLeds();

    /* Main loop: All reception and authentication handled in ISR (canIsrRxHandler) */
    while (1)
    {
        /* Idle loop – work is interrupt driven */
    }
}
