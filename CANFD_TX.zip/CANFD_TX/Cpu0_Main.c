#include "Ifx_Types.h"
#include "IfxCpu.h"
#include "IfxScuWdt.h"
#include "MCMCAN.h"

IFX_ALIGN(4) IfxCpu_syncEvent g_cpuSyncEvent = 0;

void core0_main(void)
{
    /* Enable global interrupts */
    IfxCpu_enableInterrupts();

    /* Disable CPU and Safety watchdogs */
    IfxScuWdt_disableCpuWatchdog(IfxScuWdt_getCpuWatchdogPassword());
    IfxScuWdt_disableSafetyWatchdog(IfxScuWdt_getSafetyWatchdogPassword());

    /* Wait for CPU sync */
    IfxCpu_emitEvent(&g_cpuSyncEvent);
    IfxCpu_waitEvent(&g_cpuSyncEvent, 1);

    /* Initialize CAN-FD and LEDs */
    initMcmcan();
    initLeds();

    uint16 counter = 0;

    while (1)
    {
        sendCanMessage(counter++);   /* Send CAN-FD frame */

        /* Simple delay between transmissions */
        for (volatile uint32 i = 0; i < 10000000; i++) { }
    }
}
